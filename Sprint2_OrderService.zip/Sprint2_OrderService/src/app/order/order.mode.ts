export interface Order {
    id?:number;
    orderName:string;
    totalPrice:number;
    status:string;
    customerId:number;

}
